<?php
// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "ashliz";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Validate input
    if (empty($name) || empty($email) || empty($message)) {
        echo "Please fill out all required fields.";
    } else {
        // Prepare SQL statement
        $sql = "INSERT INTO contacts (name, phone_number, email, message) VALUES (?, ?, ?, ?)";
        
        // Prepare and bind parameters
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $name, $phone, $email, $message);

        // Execute SQL statement
        if ($stmt->execute()) {
            echo "Your message has been sent successfully!";
        } else {
            echo "Oops! Something went wrong and we couldn't send your message.";
        }

        // Close statement
        $stmt->close();
    }
} else {
    echo "Oops! An error occurred. Please try again later.";
}

// Close connection
$conn->close();
?>
