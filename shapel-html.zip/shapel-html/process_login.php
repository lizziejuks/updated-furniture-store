<?php
// Start session
session_start();

// Include the database connection file
include 'connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the username and password from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // SQL query to insert username and hashed password into admin_users table
    $sql = "INSERT INTO admin_users (username, password) VALUES ('$username', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        // Signup successful, set session variable and redirect to dashboard or home page
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit();
    } else {
        // Signup failed, redirect back to signup page with error message
        $_SESSION['admin_signup_error'] = "Signup failed. Please try again.";
        header("Location: signup.php");
        exit();
    }
} else {
    // If the form is not submitted, redirect back to signup page
    header("Location: signup.php");
    exit();
}
?>
