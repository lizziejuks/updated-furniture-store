<?php
// Include the database connection file
include 'connect.php';

// Check if the form is submitted via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // SQL query to insert admin data into the database
    $sql = "INSERT INTO admin_users (username, password) VALUES ('$username', '$password')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        // Admin signup successful
        header("Location: admin_login.php"); // Redirect to admin login page
        exit();
    } else {
        // Admin signup failed
        echo "Error: " . $sql . "<br>" . $conn->error; // Display error message
    }
} else {
    // Redirect to admin signup page if accessed directly without submitting the form
    header("Location: admin_signup.php");
    exit();
}
?>
