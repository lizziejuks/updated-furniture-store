<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="icon" href="images/favicon.png" type="image/gif" />

  <title>Ashliz Furniture Store</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet" />

  <!-- lightbox Gallery-->
  <link rel="stylesheet" href="css/ekko-lightbox.css" />

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

  <style>
    /* Additional styles for login page */
    body {
      background-image: url('images/unsplash.jpg');
      background-size: cover;
      background-position: center;
    }

    .login-container {
      background-color: rgba(255, 255, 255, 0.8);
      padding: 20px;
      border-radius: 10px;
      margin-top: 100px;
    }

    .login-container form {
      margin-top: 20px;
    }
  </style>
</head>

<body>
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        <div class="login-container">
          <h2 class="text-center">Admin Login</h2>
          <form action="process_admin_login.php" method="post">
            <div class="form-group">
              <input type="text" class="form-control" name="username" placeholder="Username" value="Admin" required>
            </div>
            <div class="form-group">
              <input type="password" class="form-control" name="password" placeholder="Password" value="Admin123" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Login</button>
			<br>
			<br>
			 <p class="text-center">Not Admin? <a href="login.php">Customer Login</a></p>
        </div>
      </div>
    </div>
  </div>
</body>

</html>
