<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>



<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="icon" href="images/favicon.png" type="image/gif" />

  <title>Ashliz Furniture Store</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:400,600,700&display=swap" rel="stylesheet" />

  <!-- lightbox Gallery-->
  <link rel="stylesheet" href="css/ekko-lightbox.css" />

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />
  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

</head>

<body>

  <!-- header section strats -->
  <header class="header_section">
    <div class="container-fluid">
      <nav class="navbar navbar-expand-lg custom_nav-container">
        <a class="navbar-brand" href="index.html">
          <span>
            Ashliz Furniture Store
          </span>
        </a>
        <div class="" id="">

          <div class="custom_menu-btn">
            <button onclick="openNav()">
              <span class="s-1"> </span>
              <span class="s-2"> </span>
              <span class="s-3"> </span>
            </button>
            <div id="myNav" class="overlay">
              <div class="overlay-content">
                <a href="index.html">Home</a>
                <a href="about.html">About</a>
                <a href="gallery.html">Our Furnitures</a>
                <a href="service.html">Service</a>
                <a href="blog.html">Blog</a>
				<a href="logout.php">Log Out</a>
              </div>
            </div>
          </div>
        </div>
      </nav>
    </div>
  </header>
  <!-- end header section -->

  <!-- slider section -->
  <section class="slider_section position-relative">
    <div id="customCarousel1" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="img_container">
            <div class="img-box">
              <img src="images/slider-bg.jpg" class="" alt="...">
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img_container">
            <div class="img-box">
              <img src="images/slider-bg.jpg" class="" alt="...">
            </div>
          </div>
        </div>
        <div class="carousel-item">
          <div class="img_container">
            <div class="img-box">
              <img src="images/slider-bg.jpg" class="" alt="...">
            </div>
          </div>
        </div>
      </div>
      <div class="carousel_btn_box">
        <a class="carousel-control-prev" href="#customCarousel1" role="button" data-slide="prev">
          <i class="fa fa-arrow-left" aria-hidden="true"></i>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#customCarousel1" role="button" data-slide="next">
          <i class="fa fa-arrow-right" aria-hidden="true"></i>
          <span class="sr-only">Next</span>
        </a>
      </div>
    </div>
    <div class="detail-box">
      <div class="col-md-8 col-lg-6 mx-auto">
        <div class="inner_detail-box">
          <h1>
            Interior and Exterior Furniture Design <br>
            Studio
          </h1>
          <p>
            Discover a world of timeless elegance and unparalleled craftsmanship at our Furniture Store. From exquisite interior pieces to stunning outdoor designs, we bring your vision to life with our curated selection of furniture. Elevate your living spaces with our sophisticated collections, meticulously crafted to enhance comfort and style. Explore our website to find the perfect pieces for your home or office. Let us transform your space into a reflection of your unique taste and personality. Contact us today to embark on your journey towards exceptional furniture design.
          </p>
          <div>
            <a href="contact.php" class="slider-link">
              CONTACT US
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end slider section -->

  <!-- about section -->

  <section class="about_section layout_padding ">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="img-box">
            <img src="images/about-img.jpg" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                About Us
              </h2>
            </div>
            <p>
			Welcome to our Furniture Store - where passion meets craftsmanship.

At our core, we are dedicated to creating spaces that resonate with beauty, comfort, and functionality. Our journey began with a vision to redefine furniture design, blending classic elegance with modern sensibilities.

Driven by a relentless pursuit of excellence, our team of artisans and designers pour their heart and soul into every piece we create. From the initial concept to the final finishing touches, attention to detail is paramount.

With a commitment to quality and innovation, we strive to exceed expectations and inspire dreams. Explore our collection and let us be your partner in transforming your living spaces into true reflections of your style and personality.

Discover the artistry behind our brand, and join us in crafting unforgettable experiences in every room of your home.
             </p>
            <a href="about.html">
              Read More
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- gallery section -->

  <div class="gallery_section layout_padding2">
    <div class="container-fluid">
      <div class="heading_container heading_center">
        <h2>
          Available Furnitures
        </h2>
      </div>
      <div class="row">
        <div class=" col-sm-8 col-md-6 px-0">
          <div class="img-box">
            <img src="images/g1.jpg" alt="">
            <a href="images/g1.jpg" data-toggle="lightbox" data-gallery="gallery">
              <i class="fa fa-picture-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-sm-4 col-md-3 px-0">
          <div class="img-box">
            <img src="images/g2.jpg" alt="">
            <a href="images/g2.jpg" data-toggle="lightbox" data-gallery="gallery">
              <i class="fa fa-picture-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 px-0">
          <div class="img-box">
            <img src="images/g3.jpg" alt="">
            <a href="images/g3.jpg" data-toggle="lightbox" data-gallery="gallery">
              <i class="fa fa-picture-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 px-0">
          <div class="img-box">
            <img src="images/g4.jpg" alt="">
            <a href="images/g4.jpg" data-toggle="lightbox" data-gallery="gallery">
              <i class="fa fa-picture-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-sm-4 col-md-3 px-0">
          <div class="img-box">
            <img src="images/g5.jpg" alt="">
            <a href="images/g5.jpg" data-toggle="lightbox" data-gallery="gallery">
              <i class="fa fa-picture-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
        <div class="col-sm-8 col-md-6 px-0">
          <div class="img-box">
            <img src="images/g6.jpg" alt="">
            <a href="images/g6.jpg" data-toggle="lightbox" data-gallery="gallery">
              <i class="fa fa-picture-o" aria-hidden="true"></i>
            </a>
          </div>
        </div>
      </div>
      <div class="btn-box">
        <a href="gallery.html">
          View All
        </a>
      </div>
    </div>
  </div>

  <!-- end gallery section -->


  <!-- service section -->

  <section class="service_section layout_padding">
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Services
        </h2>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="images/s1.jpg" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Home Staging Services
              </h5>
              <p>
			  Transform your property into a buyer's dream with our professional home staging services. We expertly showcase your home's best features, maximizing its appeal and helping you sell faster at the best price.
               </p>
              <a href="service.html">
                Read More
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="images/s2.jpg" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Custom Furniture Design
              </h5>
              <p>
			  Elevate your space with bespoke furniture tailored to your unique style and requirements. Our skilled craftsmen work closely with you to bring your vision to life, ensuring every piece reflects your personality and enhances your living environment.
              </p>
              <a href="service.html">
                Read More
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="images/s3.jpg" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Interior Design Consultation
              </h5>
              <p>
			  Let our experienced interior designers breathe new life into your home or office. From space planning to color schemes, we provide personalized consultations to help you create functional, stylish interiors that align with your lifestyle and taste.
              </p>
              <a href="service.html">
                Read More
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>

  <!-- end service section -->



  <!-- blog section -->

  <section class="blog_section ">
    <div class="container-fluid">
      <div class="heading_container">
        <h2>
          Latest Insights
        </h2>
      </div>
      <div class="row">
        <div class="col-lg-6 ">
          <div class="box">
            <div class="img-box">
              <img src="images/b1.jpg" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Unlocking Timeless Beauty
              </h5>
              <p>
			  Explore the art of timeless design as we delve into the principles of classic elegance and sophistication. Discover how to incorporate timeless pieces into your home to create a space that transcends trends and stands the test of time.
                </p>
              <a href="blog.html">
                Read More
              </a>
            </div>
          </div>
        </div>
        <div class="col-lg-6 ">
          <div class="box">
            <div class="img-box">
              <img src="images/b2.jpg" alt="">
            </div>
            <div class="detail-box">
              <h5>
                Embracing Minimalism: Less is More
              </h5>
              <p>
			  Learn the secrets of minimalist design and how to create serene and clutter-free interiors that promote tranquility and mindfulness. Find out how to streamline your living spaces for maximum comfort and visual appeal without sacrificing style.
               </p>
              <a href="blog.html">
                Read More
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end blog section -->

  <!-- client section -->

  <section class="client_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Testimonial
        </h2>
      </div>
      <div id="carouselExample2Controls" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <div class="row">
              <div class="col-md-11 col-lg-10 mx-auto">
                <div class="box">
                  <div class="img-box">
                    <img src="images/client.jpg" alt="" />
                  </div>
                  <div class="detail-box">
                    <div class="name">
                      <h6>
                        Jack
                      </h6>
                    </div>
                    <p>
					I was impressed by the professionalism and attention to detail. The team went above and beyond to ensure my satisfaction
                    </p>
                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="row">
              <div class="col-md-11 col-lg-10 mx-auto">
                <div class="box">
                  <div class="img-box">
                    <img src="images/client.jpg" alt="" />
                  </div>
                  <div class="detail-box">
                    <div class="name">
                      <h6>
                        Emilly
                      </h6>
                    </div>
                    <p>
                     From start to finish, the process was seamless. Communication was excellent, and the end result exceeded my expectations.
                    </p>
                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="carousel-item">
            <div class="row">
              <div class="col-md-11 col-lg-10 mx-auto">
                <div class="box">
                  <div class="img-box">
                    <img src="images/client.jpg" alt="" />
                  </div>
                  <div class="detail-box">
                    <div class="name">
                      <h6>
                        Michael
                      </h6>
                    </div>
                    <p>
                      Working with this company was a pleasure. They listened to my needs and delivered a solution that perfectly suited my requirements.
                    </p>
                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="carousel_btn-container">
          <a class="carousel-control-prev" href="#carouselExample2Controls" role="button" data-slide="prev">
            <i class="fa fa-long-arrow-left" aria-hidden="true"></i>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExample2Controls" role="button" data-slide="next">
            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- end client section -->

  <!-- contact section -->
<section class="contact_section  ">
  <div class="container">
    <div class="row">
      <div class="col-md-7 col-lg-6 ">
        <div class="form_container">
          <div class="heading_container ">
            <h2>
              Contact Us
            </h2>
          </div>
          <form action="process_contacts.php" method="post">
            <div>
              <input type="text" name="name" class="form-control" placeholder="Your Name" />
            </div>
            <div>
              <input type="text" name="phone" class="form-control" placeholder="Phone Number" />
            </div>
            <div>
              <input type="email" name="email" class="form-control" placeholder="Email" />
            </div>
            <div>
              <textarea name="message" class="form-control message-box" placeholder="Message"></textarea>
            </div>
            <div class="btn_box">
              <button type="submit">
                SEND
              </button>
            </div>
          </form>
        </div>
      </div>
      <div class="col-md-5 col-lg-6">
        <div class="subscribe-box">
          <h3>
            Subscribe To Our Newsletter
          </h3>
          <p>
            Stay updated with the latest news, tips, and offers by subscribing to our newsletter. Enter your email address below and hit subscribe to join our community. We respect your privacy and won't spam you with unnecessary emails. Subscribe now and be part of our growing family!
          </p>
          <form action="">
            <input type="email" class="form-control" placeholder="Enter your email">
            <button>
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end contact section -->

  <!-- info section -->
  <section class="info_section ">
    <div class="container">
      <div class="row info_main_row">
        <div class="col-md-6 col-lg-3">
          <div class="info_insta">
            <h4>
              <a href="index.html" class="navbar-brand m-0 p-0">
                <span>
                  Ashliz Furnitures
                </span>
              </a>
            </h4>
            <p class="mb-0">
			Welcome to Ashliz Furnitures, where we believe in transforming spaces into inspiring environments. With a keen eye for design and a passion for creativity, we strive to bring your vision to life. Our team is dedicated to providing exceptional interior and exterior furniture design solutions that exceed your expectations.
            </p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <div class="info_detail">
            <h4>
              Company
            </h4>
            <p class="mb-0">
			At Ashliz Furnitures, we pride ourselves on delivering quality craftsmanship and outstanding service. Our commitment to excellence is evident in every project we undertake. From concept to completion, we ensure attention to detail and a personalized approach to meet your unique needs.
            </p>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <h4>
            Contact Us
          </h4>
          <div class="info_contact">
            <a href="location.html">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <span>
                Ruiru
              </span>
            </a>
            <a href="">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Call +254 792483365
              </span>
            </a>
			<a href="">
              <i class="fa fa-phone" aria-hidden="true"></i>
              <span>
                Call +254 702581939
              </span>
            </a>
            <a href="">
              <i class="fa fa-envelope"></i>
              <span>
                elizabethatieno2218@gmail.com
              </span>
            </a>
          </div>
        </div>
        <div class="col-md-6 col-lg-3">
          <h4>
            Follow Us
          </h4>
          <div class="social_box">
            <a href="">
              <i class="fa fa-facebook" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-twitter" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-linkedin" aria-hidden="true"></i>
            </a>
            <a href="">
              <i class="fa fa-instagram" aria-hidden="true"></i>
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end info_section -->


  <!-- footer section -->
  <footer class="footer_section">
    <div class="container">
      <p>
        &copy; <span id="displayYear"></span> All Rights Reserved By
        <a href="https://html.design/">Ashliz Furnitures</a>
      </p>
    </div>
  </footer>
  <!-- footer section -->


  <!-- jQery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- lightbox Gallery-->
  <script src="js/ekko-lightbox.min.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>

</body>

</html>