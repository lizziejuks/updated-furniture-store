<?php
// Include the database connection file
include 'connect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate input
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        echo "Please fill out all required fields.";
    } elseif ($password != $confirm_password) {
        echo "Password and confirm password do not match.";
    } else {
        // Check if username or email already exists
        $check_query = "SELECT * FROM users WHERE username='$username' OR email='$email'";
        $check_result = $conn->query($check_query);
        if ($check_result->num_rows > 0) {
            echo "Username or email already exists. Please try again with different credentials.";
        } else {
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert user data into the database
            $insert_query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
            if ($conn->query($insert_query) === TRUE) {
                echo "User registered successfully!";
                // Redirect to login page
                header("Location: login.php");
                exit();
            } else {
                echo "Error: " . $insert_query . "<br>" . $conn->error;
            }
        }
    }
} else {
    echo "Oops! An error occurred. Please try again later.";
}
?>
