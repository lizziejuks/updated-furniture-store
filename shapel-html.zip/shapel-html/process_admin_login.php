<?php
session_start();

// Check if the form is submitted via POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Define default admin credentials
    $default_username = "Admin";
    $default_password = "Admin123";

    // Collect form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if username and password match default admin credentials
    if ($username === $default_username && $password === $default_password) {
        // Admin login successful
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin/index.php"); // Redirect to admin dashboard
        exit();
    } else {
        // Admin login failed
        $_SESSION['admin_login_error'] = "Invalid username or password";
        header("Location: admin_login.php?error=Invalid credentials"); // Redirect back to admin login page with error message
        exit();
    }
} else {
    // Redirect to admin login page if accessed directly without submitting the form
    header("Location: admin_login.php");
    exit();
}
?>
